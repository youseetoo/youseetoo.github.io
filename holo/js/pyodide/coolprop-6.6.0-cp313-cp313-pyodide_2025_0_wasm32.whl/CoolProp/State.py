from __future__ import absolute_import
# We made everything build into one module for simplicity as it makes the code much nicer to compile
from .CoolProp import *
