# UC2 FRAME Configuration Image Generator - Project Overview

## What This Package Does

Automatically generates professional preview images for all UC2 FRAME hardware configurations by intelligently compositing component images based on configuration names.

### Key Features

✅ **Automated Batch Processing** - Generates 24 configuration images in seconds  
✅ **Smart Component Detection** - Automatically selects correct parts based on naming  
✅ **Customizable Layout** - Easy position and scale adjustments  
✅ **Professional Output** - High-quality 1920×1080 PNG images  
✅ **Cross-Platform** - Works on Windows, macOS, and Linux  
✅ **Interactive Tools** - Preview and test individual configurations  

## Package Contents

### Main Scripts

1. **generate_frame_configs.py** (500+ lines)
   - Core image generation engine
   - Handles component composition, positioning, scaling
   - Supports batch and single-file generation
   - Fully documented with inline comments

2. **preview_tool.py** (200+ lines)
   - Interactive menu for testing configurations
   - Preview individual images before batch processing
   - Automatic image viewing after generation

3. **generate_all.bat** (Windows)
   - One-click batch generation for Windows users
   - Automatic dependency checking and installation
   - Opens output folder when complete

4. **generate_all.sh** (Linux/Mac)
   - One-click batch generation for Unix systems
   - Automatic dependency checking and installation
   - Executable permissions pre-set

### Documentation

1. **README.md** - Comprehensive documentation (200+ lines)
   - Complete usage guide
   - Configuration naming conventions
   - Customization instructions
   - Troubleshooting section

2. **SETUP_GUIDE.md** - Quick start guide
   - Step-by-step installation
   - Quick start methods
   - Common issues and solutions
   - Example workflows

3. **config_example.py** - Configuration reference
   - All available settings with explanations
   - Position coordinate system
   - Scale factor guidelines
   - Customization tips

4. **requirements.txt** - Python dependencies
   - Single dependency: Pillow (PIL)

### Component Images

Located in `frame_configs/IMAGES/`:

- **FRAME_with_illuarm.png** (1920×1080) - Base FRAME with illumination arm
- **FRAME_without_illuarm.png** (1920×1080) - Base FRAME standalone
- **led_matrix.png** (1920×1080) - LED Matrix module
- **led_1x.png** (1920×1080) - Single-channel LED
- **led_4x.webp** (1080×720) - 4-channel LED module
- **laser_1x.png** (1920×1080) - 1x optical filter
- **laser_2x.png** (1920×1080) - 2x optical filter
- **laser_4x.png** (1920×1080) - 4x optical filter
- **autofocus_laser.png** (1920×1080) - Laser autofocus system

### Configuration Files

24 SVG placeholder files in `frame_configs/`:
- Naming pattern: `frame_{lightSource}_{autofocus}_{fluorescence}.svg`
- Serve as templates for output naming
- Full list in README.md

### Sample Outputs

Located in `sample_outputs/`:
- 4 example generated images
- Reference image for comparison
- Demonstrates different configuration types

## How It Works

### 1. Configuration Parsing

The script reads SVG filenames like:
```
frame_ledmatrix_laserastigmatism_fluo.svg
```

And extracts components:
- Light source: `ledmatrix`
- Autofocus: `laserastigmatism`
- Fluorescence: `fluo`

### 2. Component Selection

Based on the configuration, it selects appropriate images:

```python
ledmatrix + fluo → LED Matrix + 4x Filter + 4 Channel LED + FRAME with arm
singleled + none → Single LED + 1x Filter + FRAME without arm
```

### 3. Image Composition

Layers components on a 1920×1080 canvas:

```
Layer 1: White background
Layer 2: Base FRAME (center, 70% scale)
Layer 3: LED module (top-left, 20% scale)
Layer 4: Autofocus laser (if applicable)
Layer 5: Filter indicator (upper-right, 20% scale)
Layer 6: 4-channel LED (lower-right, 25% scale)
Layer 7: Labels and title
```

### 4. Output Generation

Saves optimized PNG files with descriptive names.

## Configuration Mapping Logic

### Base FRAME Selection

| Autofocus Type | FRAME Variant |
|----------------|---------------|
| laserastigmatism | with_illuarm |
| imagecontrast | with_illuarm |
| none | without_illuarm |

### Light Source Mapping

| Config Value | Component | Channels |
|--------------|-----------|----------|
| ledmatrix | led_matrix.png | 1 or 4* |
| ledring | led_matrix.png | 1 or 4* |
| singleled | led_1x.png | 1 |
| none | (none) | 0 |

*4 channels if fluorescence enabled

### Filter Selection

| Channels | Filter Image |
|----------|--------------|
| 1 | laser_1x.png |
| 2 | laser_2x.png |
| 4 | laser_4x.png |

### Auto-Generated Titles

Examples:
- `frame_ledmatrix_laserastigmatism_fluo.svg` → **"FRAME 4 Channel LED Matrix Laser Autofocus"**
- `frame_singleled_none_nofluo.svg` → **"FRAME Single LED"**
- `frame_none_imagecontrast_fluo.svg` → **"FRAME No LED Image Contrast AF"**

## Customization Quick Reference

### Position Adjustment

```python
'led_matrix': {
    'position': (300, 200),    # Move to top-left
    'position': (1500, 200),   # Move to top-right
    'position': (300, 800),    # Move to bottom-left
    'position': (1500, 800),   # Move to bottom-right
}
```

### Scale Adjustment

```python
'frame_base': {
    'scale': 0.5,   # Half size (small)
    'scale': 0.7,   # 70% (recommended)
    'scale': 1.0,   # Full size (very large)
}
```

### Label Customization

```python
'led_matrix': {
    'label': 'LED Matrix',           # Default
    'label': 'Köhler Illumination',  # Custom
    'label': None,                   # No label
    'label_offset': (0, 100),        # Position below
    'label_offset': (0, -80),        # Position above
}
```

## Usage Examples

### Basic Usage

```bash
# Install dependencies
pip install -r requirements.txt

# Generate all 24 configurations
python generate_frame_configs.py

# Output: 24 PNG files in output/ directory
```

### Single Configuration

```bash
# Test a specific configuration
python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg

# Output: 1 PNG file in output/ directory
```

### Interactive Mode

```bash
# Launch interactive preview tool
python preview_tool.py

# Menu-driven interface:
# - Select configurations
# - Preview immediately
# - Batch or single generation
```

### Custom Directories

```bash
# Use custom paths
python generate_frame_configs.py \
    --svg-dir my_configs \
    --images-dir my_images \
    --output-dir final_images
```

## Performance

- **Generation Time**: ~0.5 seconds per image
- **Batch Time**: ~10-15 seconds for all 24 configurations
- **Output Size**: ~200-300 KB per image (PNG optimized)
- **Total Output**: ~6-8 MB for complete set
- **Memory Usage**: ~500 MB during processing

## Requirements

- **Python**: 3.6 or higher
- **Pillow**: 9.0.0 or higher (only dependency)
- **Disk Space**: ~10 MB for scripts + ~2 MB for component images
- **RAM**: 500 MB recommended
- **OS**: Windows 7+, macOS 10.12+, Linux (any modern distro)

## Project Structure

```
frame_config_generator/
│
├── Scripts
│   ├── generate_frame_configs.py    ← Main generator
│   ├── preview_tool.py               ← Interactive preview
│   ├── generate_all.bat              ← Windows launcher
│   └── generate_all.sh               ← Unix launcher
│
├── Documentation
│   ├── README.md                     ← Full docs
│   ├── SETUP_GUIDE.md                ← Quick start
│   ├── config_example.py             ← Settings reference
│   ├── requirements.txt              ← Dependencies
│   └── THIS_FILE.md                  ← Project overview
│
├── Component Images
│   └── frame_configs/
│       ├── IMAGES/                   ← 9 component PNGs
│       └── *.svg                     ← 24 config templates
│
└── Sample Outputs
    └── sample_outputs/               ← 4 example images
```

## Next Steps

1. **Quick Test**
   ```bash
   python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg
   ```

2. **Customize** (optional)
   - Edit positions in `generate_frame_configs.py`
   - See `config_example.py` for guidance

3. **Generate All**
   ```bash
   python generate_frame_configs.py
   ```
   Or double-click `generate_all.bat` (Windows) / run `./generate_all.sh` (Unix)

4. **Use Images**
   - Find all images in `output/` directory
   - Import into FRAME wizard
   - Use in documentation

## Support Files

All documentation includes:
- Detailed explanations
- Code examples
- Troubleshooting guides
- Configuration references
- Visual examples

## License

This tool is provided for UC2 FRAME configuration preview generation.

## Credits

- Component images: UC2 FRAME project
- Script: Python + Pillow (PIL)
- Compatible with: UC2 FRAME wizard preview system

---

**Ready to generate? See SETUP_GUIDE.md for installation instructions!**
