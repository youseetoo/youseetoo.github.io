# Example Configuration Settings
# Copy values from this file into generate_frame_configs.py to customize

# Canvas Settings
CANVAS_WIDTH = 1920
CANVAS_HEIGHT = 1080
CANVAS_COLOR = (255, 255, 255, 255)  # White background (RGBA)

# Component Positions and Scales
# Format for each component:
# 'component_name': {
#     'position': (x, y),           # Pixel coordinates from top-left
#     'scale': 0.0-1.0,             # Scale factor
#     'anchor': 'center',           # Position anchor point
#     'label': 'Text',              # Optional label
#     'label_offset': (x, y)        # Label position offset
# }

COMPONENT_CONFIGS = {
    # Main FRAME - centered in canvas
    'frame_base': {
        'position': (960, 540),     # Center of 1920x1080
        'scale': 0.7,               # 70% of original size
        'anchor': 'center'
    },
    
    # LED Matrix - top left
    'led_matrix': {
        'position': (300, 200),     # Top-left quadrant
        'scale': 0.2,               # 20% size
        'anchor': 'center',
        'label': 'LED Matrix',
        'label_offset': (0, 100)    # 100px below component
    },
    
    # Single LED - same position as matrix (alternative)
    'led_1x': {
        'position': (300, 200),
        'scale': 0.2,
        'anchor': 'center',
        'label': '1 Channel LED',
        'label_offset': (0, 100)
    },
    
    # LED Ring - same position as matrix (alternative)
    'led_ring': {
        'position': (300, 200),
        'scale': 0.2,
        'anchor': 'center',
        'label': 'LED Ring',
        'label_offset': (0, 100)
    },
    
    # 4 Channel LED module - lower right
    'led_4x': {
        'position': (1500, 700),    # Lower-right quadrant
        'scale': 0.25,              # 25% size
        'anchor': 'center',
        'label': '4 Channel LED',
        'label_offset': (0, 80)
    },
    
    # Autofocus laser - overlays on frame
    'autofocus_laser': {
        'position': (960, 300),     # Above center
        'scale': 0.15,              # 15% size (small overlay)
        'anchor': 'center'
    },
    
    # Filter indicators - upper right
    'laser_1x': {
        'position': (1500, 300),
        'scale': 0.2,
        'anchor': 'center',
        'label': '1x Filter',
        'label_offset': (0, 80)
    },
    
    'laser_2x': {
        'position': (1500, 300),
        'scale': 0.2,
        'anchor': 'center',
        'label': '2x Filter',
        'label_offset': (0, 80)
    },
    
    'laser_4x': {
        'position': (1500, 300),
        'scale': 0.2,
        'anchor': 'center',
        'label': '4x Filter',
        'label_offset': (0, 80)
    }
}

# Title Settings
TITLE_CONFIG = {
    'position': (960, 100),         # Top center
    'font_size': 72,                # Large title font
    'color': (30, 70, 112),         # Dark blue (RGB)
    'font_family': 'arial.ttf'      # Will fall back if not found
}

# Label Settings (used for component labels)
LABEL_FONT_SIZE = 32
LABEL_COLOR = (50, 50, 50)          # Dark gray (RGB)

# Tips for Customization:
# 
# 1. Position Coordinates:
#    - (0, 0) is top-left corner
#    - (1920, 1080) is bottom-right corner
#    - (960, 540) is exact center
#
# 2. Scale Factors:
#    - 1.0 = original size (1920x1080 for most components)
#    - 0.5 = half size
#    - 0.2 = 20% of original (good for small components)
#
# 3. Anchor Points:
#    - 'center': position refers to center of image
#    - 'top-left': position refers to top-left corner
#    (extend code for more anchor types if needed)
#
# 4. Color Format:
#    - RGB: (red, green, blue) values 0-255
#    - RGBA: (red, green, blue, alpha) for transparency
#
# 5. Testing Changes:
#    After modifying values in generate_frame_configs.py:
#    python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg
#    This generates just one image for quick testing
