#!/bin/bash
# Quick Start Script for Linux/Mac
# This script generates all FRAME configuration preview images

echo "================================================"
echo "UC2 FRAME Configuration Image Generator"
echo "================================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.6+ from your package manager"
    exit 1
fi

echo "Python found: $(python3 --version)"
echo ""

# Check if Pillow is installed
if ! python3 -c "import PIL" &> /dev/null; then
    echo "Installing required package: Pillow..."
    pip3 install Pillow
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to install Pillow"
        echo "Try: pip3 install --user Pillow"
        exit 1
    fi
    echo ""
fi

echo "Pillow library is ready!"
echo ""

# Run the generator
echo "Generating all configuration images..."
echo ""
python3 generate_frame_configs.py

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Image generation failed"
    exit 1
fi

echo ""
echo "================================================"
echo "SUCCESS! Images saved to 'output' directory"
echo "================================================"
echo ""

# Try to open output folder (works on macOS and some Linux)
if [[ "$OSTYPE" == "darwin"* ]]; then
    open output 2>/dev/null
elif command -v xdg-open &> /dev/null; then
    xdg-open output 2>/dev/null
fi
