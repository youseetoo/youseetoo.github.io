# UC2 FRAME Configuration Image Generator

A Python script that automatically generates preview images for different UC2 FRAME configurations by compositing component images.

## Overview

This script takes component images (FRAME base, LED modules, autofocus lasers, filters) and combines them into professional configuration preview images based on naming conventions.

### Generated Image Layout

Each configuration image includes:
- **Title** (top center): Descriptive name based on configuration
- **LED Matrix/Ring/Single LED** (top left): Light source component with label
- **Main FRAME** (center): Base FRAME with or without illumination arm
- **4x Filter** (upper right): Filter indicator for multi-channel configurations
- **4 Channel LED** (lower right): LED module for 4-channel configurations

## Requirements

- Python 3.6+
- Pillow (PIL) library

### Installation

```bash
pip install Pillow
```

## Directory Structure

```
.
├── generate_frame_configs.py     # Main script
├── frame_configs/                # Configuration files
│   ├── frame_*.svg              # SVG config files (placeholders)
│   └── IMAGES/                  # Component images
│       ├── FRAME_with_illuarm.png
│       ├── FRAME_without_illuarm.png
│       ├── led_matrix.png
│       ├── led_1x.png
│       ├── led_4x.webp
│       ├── laser_1x.png
│       ├── laser_2x.png
│       ├── laser_4x.png
│       └── autofocus_laser.png
└── output/                       # Generated images (created automatically)
```

## Usage

### Generate All Configurations

```bash
python generate_frame_configs.py
```

This will generate preview images for all SVG configuration files in the `frame_configs/` directory.

### Generate Specific Configuration

```bash
python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg
```

### Custom Directories

```bash
python generate_frame_configs.py \
    --svg-dir /path/to/configs \
    --images-dir /path/to/images \
    --output-dir /path/to/output
```

### Command-Line Arguments

- `--svg-dir`: Directory containing SVG configuration files (default: `frame_configs`)
- `--images-dir`: Directory containing component images (default: `frame_configs/IMAGES`)
- `--output-dir`: Directory to save generated images (default: `output`)
- `--config`: Generate only a specific configuration file

## Configuration Naming Convention

Files follow the pattern: `frame_{lightSource}_{autofocus}_{fluorescence}.svg`

### Light Source Options
- `ledmatrix`: LED Matrix illumination
- `ledring`: LED Ring (Köhler illumination)
- `singleled`: Single LED
- `none`: No LED light source

### Autofocus Options
- `laserastigmatism`: Laser-based autofocus with astigmatism
- `imagecontrast`: Image contrast-based autofocus
- `none`: No autofocus

### Fluorescence Options
- `fluo`: Fluorescence capability enabled
- `nofluo`: No fluorescence

### Examples

```
frame_ledmatrix_laserastigmatism_fluo.svg
→ LED Matrix + Laser Autofocus + Fluorescence (4-channel)
→ Title: "FRAME 4 Channel LED Matrix Laser Autofocus"

frame_singleled_none_nofluo.svg
→ Single LED + No Autofocus + No Fluorescence
→ Title: "FRAME Single LED"

frame_none_imagecontrast_fluo.svg
→ No LED + Image Contrast AF + Fluorescence
→ Title: "FRAME No LED Image Contrast AF"
```

## Customization

### Adjusting Component Positions and Scales

Edit the `COMPONENT_CONFIGS` dictionary in `generate_frame_configs.py`:

```python
COMPONENT_CONFIGS = {
    'led_matrix': {
        'position': (300, 200),      # (x, y) in pixels
        'scale': 0.2,                # Scale factor (0.0 - 1.0)
        'anchor': 'center',          # Anchor point
        'label': 'LED Matrix',       # Label text
        'label_offset': (0, 100)     # Label position offset
    },
    # ... other components
}
```

### Adjusting Canvas Size

Modify these constants:

```python
CANVAS_WIDTH = 1920
CANVAS_HEIGHT = 1080
CANVAS_COLOR = (255, 255, 255, 255)  # RGBA
```

### Adjusting Title Style

Modify the `TITLE_CONFIG` dictionary:

```python
TITLE_CONFIG = {
    'position': (960, 100),
    'font_size': 72,
    'color': (30, 70, 112),  # RGB
}
```

### Adding New Component Types

1. Add component image to `IMAGES/` directory
2. Add configuration to `COMPONENT_CONFIGS`
3. Update `get_components_for_config()` function to include new component in appropriate configurations

## Component Mapping Rules

The script automatically determines which components to include based on the configuration:

### Base FRAME
- **With illumination arm**: Used when autofocus is `laserastigmatism` or `imagecontrast`
- **Without illumination arm**: Used when autofocus is `none`

### Light Sources
- `ledmatrix` → `led_matrix.png`
- `ledring` → `led_matrix.png` (placeholder, can be customized)
- `singleled` → `led_1x.png`

### Channel Count & Filters
- Determined by light source and fluorescence:
  - Single LED = 1 channel → `laser_1x.png` filter
  - LED Matrix/Ring without fluorescence = 1 channel → `laser_1x.png`
  - LED Matrix/Ring with fluorescence = 4 channels → `laser_4x.png` + `led_4x.webp`

### Autofocus
- `laserastigmatism` → `autofocus_laser.png` overlay

## Output

Generated images are:
- **Format**: PNG
- **Size**: 1920×1080 pixels (configurable)
- **Naming**: Same as input SVG files, with `.png` extension
- **Location**: `output/` directory (or custom `--output-dir`)

## Troubleshooting

### "Component image not found"
- Ensure all component images are in the `IMAGES/` directory
- Check file names match exactly (case-sensitive)
- Verify image file extensions (.png, .webp)

### "No configuration found for"
- Ensure `COMPONENT_CONFIGS` has an entry for the component
- Check the configuration key matches

### Font errors
- Script uses system fonts, falls back to default if unavailable
- Install DejaVu fonts for better appearance:
  ```bash
  # Ubuntu/Debian
  sudo apt-get install fonts-dejavu
  
  # macOS (usually pre-installed)
  # Windows (usually has Arial)
  ```

### Memory issues with large images
- Component images are 1920×1080, which is memory-intensive
- Consider reducing source image sizes if needed
- Process configurations in smaller batches

## Advanced Usage

### Batch Processing with Custom Rules

You can modify the script to process only certain types:

```python
# Generate only fluorescence configs
svg_files = [f for f in svg_dir.glob('frame_*_fluo.svg')]

# Generate only LED matrix configs
svg_files = [f for f in svg_dir.glob('frame_ledmatrix_*.svg')]
```

### Parallelization

For large batches, you can parallelize:

```python
from multiprocessing import Pool

def process_config(svg_file):
    generate_config_image(svg_file.name, images_dir, output_dir)

with Pool() as pool:
    pool.map(process_config, svg_files)
```

## License

This script is provided as-is for UC2 FRAME configuration preview generation.

## Support

For issues or questions:
1. Check component image files exist and have correct names
2. Verify Python and Pillow versions
3. Review configuration naming convention
4. Check error messages for specific issues

## Examples of Generated Images

### 4-Channel LED Matrix with Laser Autofocus
```bash
python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg
```
Includes: LED Matrix (top-left), FRAME with illumination arm, Laser AF overlay, 4x filter, 4 Channel LED module

### Simple Single LED
```bash
python generate_frame_configs.py --config frame_singleled_none_nofluo.svg
```
Includes: Single LED (top-left), FRAME without illumination arm, 1x filter

### No Light Source with Fluorescence
```bash
python generate_frame_configs.py --config frame_none_none_fluo.svg
```
Includes: FRAME without illumination arm, 4x filter, 4 Channel LED (for fluorescence detection)
