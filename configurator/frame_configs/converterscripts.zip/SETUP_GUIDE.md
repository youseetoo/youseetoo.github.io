# Quick Setup Guide - UC2 FRAME Configuration Image Generator

## Step-by-Step Installation

### 1. Prerequisites

You need Python 3.6 or higher installed on your computer.

**Check if Python is installed:**

```bash
# Windows (Command Prompt or PowerShell)
python --version

# macOS/Linux
python3 --version
```

**If Python is not installed:**
- Windows: Download from [python.org](https://www.python.org/downloads/)
- macOS: `brew install python3` (requires Homebrew)
- Linux: `sudo apt-get install python3 python3-pip` (Ubuntu/Debian)

### 2. Install Required Library

```bash
# Windows
pip install Pillow

# macOS/Linux
pip3 install Pillow

# Or use the requirements file
pip install -r requirements.txt
```

### 3. Verify Directory Structure

Make sure your files are organized like this:

```
your_folder/
├── generate_frame_configs.py    # Main script
├── generate_all.bat              # Windows quick-start
├── generate_all.sh               # Linux/Mac quick-start
├── preview_tool.py               # Interactive preview
├── requirements.txt              # Dependencies
├── README.md                     # Full documentation
└── frame_configs/
    ├── frame_*.svg               # Configuration files (24 files)
    └── IMAGES/
        ├── FRAME_with_illuarm.png
        ├── FRAME_without_illuarm.png
        ├── led_matrix.png
        ├── led_1x.png
        ├── led_4x.webp
        ├── laser_1x.png
        ├── laser_2x.png
        ├── laser_4x.png
        └── autofocus_laser.png
```

## Quick Start Methods

### Method 1: Easy Way (Recommended for Beginners)

**Windows:**
1. Double-click `generate_all.bat`
2. Wait for processing
3. Find images in the `output/` folder

**macOS/Linux:**
1. Open Terminal in this folder
2. Run: `./generate_all.sh`
3. Find images in the `output/` folder

### Method 2: Command Line

```bash
# Generate all configurations
python generate_frame_configs.py

# Generate specific configuration
python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg

# Custom directories
python generate_frame_configs.py \
    --svg-dir /path/to/configs \
    --images-dir /path/to/images \
    --output-dir /path/to/output
```

### Method 3: Interactive Preview Tool

For testing and customization:

```bash
python preview_tool.py
```

This opens an interactive menu where you can:
- Generate individual configurations
- Test position/scale changes
- Preview images immediately

## Customizing Positions and Scales

### Quick Adjustments

Edit `generate_frame_configs.py` and find the `COMPONENT_CONFIGS` section:

```python
COMPONENT_CONFIGS = {
    'led_matrix': {
        'position': (300, 200),    # ← Change these values
        'scale': 0.2,              # ← And this one
        'anchor': 'center',
        'label': 'LED Matrix',
        'label_offset': (0, 100)
    },
    # ... more components
}
```

### Position Coordinates

The canvas is 1920×1080 pixels:
- Top-left corner: (0, 0)
- Top-right corner: (1920, 0)
- Bottom-left corner: (0, 1080)
- Bottom-right corner: (1920, 1080)
- Center: (960, 540)

**Example positions:**
- Top-left quadrant: (480, 270)
- Top-right quadrant: (1440, 270)
- Bottom-left quadrant: (480, 810)
- Bottom-right quadrant: (1440, 810)

### Scale Factors

- `1.0` = Original size (usually 1920×1080)
- `0.5` = Half size (960×540)
- `0.25` = Quarter size (480×270)
- `0.2` = 20% size (384×216)

Recommended scales:
- Main FRAME: 0.6 - 0.8
- LED modules: 0.15 - 0.25
- Filters: 0.15 - 0.25
- Small overlays: 0.1 - 0.2

### Testing Your Changes

After modifying positions/scales:

```bash
# Test with one configuration first
python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg

# If it looks good, generate all
python generate_frame_configs.py
```

## Common Issues & Solutions

### "ModuleNotFoundError: No module named 'PIL'"
**Solution:** Install Pillow
```bash
pip install Pillow
```

### "FileNotFoundError: No such file or directory"
**Solution:** Make sure you're running the script from the correct directory
```bash
cd /path/to/frame_configs_folder
python generate_frame_configs.py
```

### "Warning: Component image not found"
**Solution:** Check that all images exist in `frame_configs/IMAGES/`
```bash
ls frame_configs/IMAGES/
```

### Images look wrong or components are cut off
**Solution:** Adjust scale factors or positions in COMPONENT_CONFIGS

### Script runs but no images appear
**Solution:** Check the output directory
```bash
ls output/
```

### Font warnings
**Solution:** Font warnings are safe to ignore. The script falls back to default fonts.

## Advanced Usage

### Batch Process Specific Types

Edit the script to filter configurations:

```python
# Only fluorescence configs
svg_files = list(svg_dir.glob('frame_*_fluo.svg'))

# Only LED matrix configs
svg_files = list(svg_dir.glob('frame_ledmatrix_*.svg'))
```

### Change Output Format

In `generate_config_image()` function:

```python
# Change from PNG to JPEG
output_canvas.save(output_path, 'JPEG', quality=95)

# Or WEBP for smaller files
output_canvas.save(output_path, 'WEBP', quality=90)
```

### Adjust Canvas Size

```python
CANVAS_WIDTH = 2560   # 2K width
CANVAS_HEIGHT = 1440  # 2K height
```

Remember to adjust component positions proportionally!

## Getting Help

1. Check `README.md` for detailed documentation
2. Review `config_example.py` for customization examples
3. Use the interactive preview tool to test changes
4. Check component image files are present and correct

## Example Workflow

1. **First time setup:**
   ```bash
   pip install Pillow
   python generate_frame_configs.py --config frame_ledmatrix_laserastigmatism_fluo.svg
   ```

2. **If you like the result:**
   ```bash
   python generate_frame_configs.py  # Generate all
   ```

3. **To customize:**
   - Edit positions in `generate_frame_configs.py`
   - Test: `python preview_tool.py`
   - Generate all: `python generate_frame_configs.py`

4. **Final output:**
   - Images saved in `output/` directory
   - Use these in your FRAME wizard or documentation

## Performance Notes

- Generating all 24 configurations takes ~10-30 seconds
- Each output image is ~200-300 KB
- Total output size: ~6-8 MB for all images

## Need More Help?

Check these files:
- `README.md` - Complete documentation
- `config_example.py` - Configuration reference
- Script comments - Inline documentation

Enjoy creating your FRAME configuration images! 🎨
