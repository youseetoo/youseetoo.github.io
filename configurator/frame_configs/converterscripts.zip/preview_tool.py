#!/usr/bin/env python3
"""
Interactive Preview Tool for FRAME Configuration Generator

This tool lets you generate a single configuration and test different
position/scale settings quickly without batch processing all configs.
"""

import sys
from pathlib import Path
from generate_frame_configs import generate_config_image, COMPONENT_CONFIGS

def list_available_configs(svg_dir: Path) -> list:
    """List all available configuration files."""
    configs = sorted(svg_dir.glob('frame_*.svg'))
    return [c.name for c in configs]

def print_menu(configs: list):
    """Print a numbered menu of configurations."""
    print("\n" + "="*60)
    print("Available FRAME Configurations")
    print("="*60)
    for i, config in enumerate(configs, 1):
        # Parse the config name to show readable description
        parts = config.replace('frame_', '').replace('.svg', '').split('_')
        light_source = parts[0] if len(parts) > 0 else 'unknown'
        autofocus = parts[1] if len(parts) > 1 else 'unknown'
        fluorescence = parts[2] if len(parts) > 2 else 'unknown'
        
        desc = f"{i:2d}. {light_source.upper():15s} | AF: {autofocus:20s} | Fluo: {fluorescence}"
        print(desc)
    print("="*60)

def print_current_settings():
    """Print current position and scale settings."""
    print("\n" + "="*60)
    print("Current Component Settings")
    print("="*60)
    for component, config in COMPONENT_CONFIGS.items():
        pos = config.get('position', 'N/A')
        scale = config.get('scale', 'N/A')
        label = config.get('label', '')
        
        if label:
            print(f"{component:20s} | Pos: {str(pos):15s} | Scale: {scale:.2f} | '{label}'")
        else:
            print(f"{component:20s} | Pos: {str(pos):15s} | Scale: {scale:.2f}")
    print("="*60)

def main():
    """Main interactive menu."""
    svg_dir = Path('frame_configs')
    images_dir = Path('frame_configs/IMAGES')
    output_dir = Path('preview_output')
    
    # Create preview output directory
    output_dir.mkdir(exist_ok=True)
    
    # Get available configurations
    configs = list_available_configs(svg_dir)
    
    if not configs:
        print("ERROR: No configuration files found in frame_configs/")
        return
    
    print("\n" + "="*60)
    print("FRAME Configuration Preview Tool")
    print("="*60)
    print("This tool helps you test individual configurations")
    print("and adjust component positions/scales interactively.")
    print("\nGenerated images are saved to 'preview_output/' directory")
    
    while True:
        print_menu(configs)
        print("\nOptions:")
        print("  1-{}: Generate specific configuration".format(len(configs)))
        print("  a: Generate ALL configurations")
        print("  s: Show current settings")
        print("  q: Quit")
        
        choice = input("\nEnter your choice: ").strip().lower()
        
        if choice == 'q':
            print("Exiting...")
            break
        
        elif choice == 'a':
            print("\nGenerating ALL configurations...")
            for config in configs:
                try:
                    output_path = generate_config_image(config, images_dir, output_dir)
                    print(f"✓ {config}")
                except Exception as e:
                    print(f"✗ {config}: {e}")
            print(f"\n✓ All images saved to {output_dir}/")
            input("\nPress Enter to continue...")
        
        elif choice == 's':
            print_current_settings()
            input("\nPress Enter to continue...")
        
        elif choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(configs):
                config = configs[idx]
                print(f"\nGenerating: {config}")
                try:
                    output_path = generate_config_image(config, images_dir, output_dir)
                    print(f"✓ Success! Saved to: {output_path}")
                    
                    # Try to open the image (platform-specific)
                    import platform
                    import subprocess
                    
                    system = platform.system()
                    try:
                        if system == 'Darwin':  # macOS
                            subprocess.run(['open', str(output_path)])
                        elif system == 'Windows':
                            subprocess.run(['start', str(output_path)], shell=True)
                        elif system == 'Linux':
                            subprocess.run(['xdg-open', str(output_path)])
                    except:
                        pass  # Silently fail if can't open
                    
                except Exception as e:
                    print(f"✗ Error: {e}")
                
                input("\nPress Enter to continue...")
            else:
                print("Invalid selection!")
        
        else:
            print("Invalid choice!")

if __name__ == '__main__':
    main()
