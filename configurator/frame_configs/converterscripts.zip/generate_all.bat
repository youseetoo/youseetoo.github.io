@echo off
REM Quick Start Script for Windows
REM This script generates all FRAME configuration preview images

echo ================================================
echo UC2 FRAME Configuration Image Generator
echo ================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.6+ from https://www.python.org/
    pause
    exit /b 1
)

echo Python found!
echo.

REM Check if Pillow is installed
python -c "import PIL" >nul 2>&1
if errorlevel 1 (
    echo Installing required package: Pillow...
    pip install Pillow
    if errorlevel 1 (
        echo ERROR: Failed to install Pillow
        pause
        exit /b 1
    )
    echo.
)

echo Pillow library is ready!
echo.

REM Run the generator
echo Generating all configuration images...
echo.
python generate_frame_configs.py

if errorlevel 1 (
    echo.
    echo ERROR: Image generation failed
    pause
    exit /b 1
)

echo.
echo ================================================
echo SUCCESS! Images saved to 'output' directory
echo ================================================
echo.

REM Open output folder
if exist output (
    start output
)

pause
